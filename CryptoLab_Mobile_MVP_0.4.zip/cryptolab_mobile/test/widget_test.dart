import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:cryptolab_mobile/main.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('renders CryptoLab mobile dashboard and navigation', (tester) async {
    SharedPreferences.setMockInitialValues({});
    final prefs = await SharedPreferences.getInstance();
    await tester.pumpWidget(MaterialApp(home: HomeShell(prefs: prefs, isDark: false, onToggleTheme: () {}, enableMarketRefresh: false)));
    expect(find.textContaining('CryptoLab'), findsOneWidget);
    expect(find.text('داشبورد معاملاتی'), findsOneWidget);
    expect(find.textContaining('نمودار کندلی'), findsOneWidget);
    expect(find.text('بازار'), findsOneWidget);
    expect(find.text('استراتژی'), findsOneWidget);
    expect(find.text('دارایی'), findsOneWidget);
  });
}
