import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

class ExchangeConnection {
  const ExchangeConnection({required this.name, required this.connected, this.message = ''});
  final String name;
  final bool connected;
  final String message;
}

class LiveMarket {
  const LiveMarket({
    required this.symbol,
    required this.name,
    required this.toman,
    required this.usdt,
    required this.changePercent,
    required this.source,
  });
  final String symbol;
  final String name;
  final double toman;
  final double usdt;
  final double changePercent;
  final String source;
}

class OhlcCandle {
  const OhlcCandle({required this.time, required this.open, required this.high, required this.low, required this.close, required this.volume});
  final DateTime time;
  final double open;
  final double high;
  final double low;
  final double close;
  final double volume;
}

class MarketDataResult {
  const MarketDataResult({required this.markets, required this.connections, required this.candles, required this.updatedAt});
  final Map<String, LiveMarket> markets;
  final List<ExchangeConnection> connections;
  final List<OhlcCandle> candles;
  final DateTime updatedAt;
}

/// Public market-data clients. No exchange API key is sent or stored here.
/// Each exchange is isolated: a failure in one adapter does not block the others.
class MarketDataService {
  MarketDataService({http.Client? client}) : _client = client ?? http.Client();
  final http.Client _client;

  static const _timeout = Duration(seconds: 12);
  static const _assets = <String, String>{
    'BTC': 'بیت‌کوین', 'ETH': 'اتریوم', 'USDT': 'تتر', 'SOL': 'سولانا', 'BNB': 'بایننس کوین',
  };

  Future<MarketDataResult> load() async {
    final results = await Future.wait([
      _loadNobitex(),
      _loadWallex(),
      _loadBitpin(),
    ]);
    final markets = <String, LiveMarket>{};
    final connections = <ExchangeConnection>[];
    for (final result in results) {
      connections.add(result.connection);
      for (final entry in result.markets.entries) {
        markets.putIfAbsent(entry.key, () => entry.value);
      }
    }

    // Prefer a real hourly candle series from the first available adapter.
    // Keep candles from one exchange only; never mix Rial, Toman and USDT OHLC series.
    var candles = results.firstWhere((e) => e.candles.isNotEmpty, orElse: () => const _AdapterResult(ExchangeConnection(name: '', connected: false), {}, [])).candles;
    if (candles.length > 80) candles = candles.sublist(candles.length - 80);
    return MarketDataResult(markets: markets, connections: connections, candles: candles, updatedAt: DateTime.now());
  }

  Future<_AdapterResult> _loadNobitex() async {
    try {
      final json = await _getJson(Uri.https('apiv2.nobitex.ir', '/market/stats'));
      final stats = _map(json['stats']);
      final usdtRial = _number(_map(stats['usdt-rls'])['latest']);
      final markets = <String, LiveMarket>{};
      for (final symbol in _assets.keys.where((s) => s != 'USDT')) {
        final row = _map(stats['${symbol.toLowerCase()}-rls']);
        final rial = _number(row['latest']);
        final change = _number(row['dayChange']);
        final usdt = usdtRial > 0 ? rial / usdtRial : 0;
        if (rial > 0) {
          markets[symbol] = LiveMarket(
            symbol: symbol, name: _assets[symbol]!, toman: rial / 10,
            usdt: usdt.toDouble(), changePercent: change, source: 'نوبیتکس',
          );
        }
      }
      if (usdtRial > 0) {
        markets['USDT'] = LiveMarket(symbol: 'USDT', name: _assets['USDT']!, toman: usdtRial / 10, usdt: 1, changePercent: _number(_map(stats['usdt-rls'])['dayChange']), source: 'نوبیتکس');
      }
      final candles = await _nobitexCandles();
      return _AdapterResult(ExchangeConnection(name: 'نوبیتکس', connected: markets.isNotEmpty), markets, candles);
    } catch (e) {
      return _AdapterResult(ExchangeConnection(name: 'نوبیتکس', connected: false, message: _shortError(e)), {}, const []);
    }
  }

  Future<List<OhlcCandle>> _nobitexCandles() async {
    try {
      final now = DateTime.now().millisecondsSinceEpoch ~/ 1000;
      final uri = Uri.https('apiv2.nobitex.ir', '/market/udf/history', {
        'symbol': 'BTCIRT', 'resolution': '60', 'from': '${now - 60 * 60 * 80}', 'to': '$now',
      });
      final json = await _getJson(uri);
      if (json['s'] != 'ok') return const [];
      final t = _list(json['t']); final o = _list(json['o']); final h = _list(json['h']);
      final l = _list(json['l']); final c = _list(json['c']); final v = _list(json['v']);
      final out = <OhlcCandle>[];
      for (var i = 0; i < t.length && i < o.length && i < h.length && i < l.length && i < c.length; i++) {
        out.add(OhlcCandle(time: DateTime.fromMillisecondsSinceEpoch(_number(t[i]).toInt() * 1000), open: _number(o[i]) / 10, high: _number(h[i]) / 10, low: _number(l[i]) / 10, close: _number(c[i]) / 10, volume: i < v.length ? _number(v[i]) : 0));
      }
      return out;
    } catch (_) { return const []; }
  }

  Future<_AdapterResult> _loadWallex() async {
    try {
      final json = await _getJson(Uri.https('api.wallex.ir', '/v1/markets'));
      final symbols = _map(_map(json['result'])['symbols']);
      final markets = <String, LiveMarket>{};
      final tomanUsdt = _wallexLast(symbols, 'USDTMN');
      for (final symbol in _assets.keys.where((s) => s != 'USDT')) {
        final toman = _wallexLast(symbols, '${symbol}TMN');
        final usdt = _wallexLast(symbols, '${symbol}USDT');
        final change = _number(_map(_map(symbols['${symbol}TMN'])['stats'])['24h_ch']);
        if (toman > 0 || usdt > 0) {
          markets[symbol] = LiveMarket(symbol: symbol, name: _assets[symbol]!, toman: toman > 0 ? toman : usdt * tomanUsdt, usdt: usdt > 0 ? usdt : (tomanUsdt > 0 ? toman / tomanUsdt : 0), changePercent: change, source: 'والکس');
        }
      }
      if (tomanUsdt > 0) markets['USDT'] = LiveMarket(symbol: 'USDT', name: _assets['USDT']!, toman: tomanUsdt, usdt: 1, changePercent: _number(_map(_map(symbols['USDTMN'])['stats'])['24h_ch']), source: 'والکس');
      final candles = await _wallexCandles();
      return _AdapterResult(ExchangeConnection(name: 'والکس', connected: markets.isNotEmpty), markets, candles);
    } catch (e) {
      return _AdapterResult(ExchangeConnection(name: 'والکس', connected: false, message: _shortError(e)), {}, const []);
    }
  }

  double _wallexLast(Map<String, dynamic> symbols, String pair) {
    final row = _map(symbols[pair]);
    final stats = _map(row['stats']);
    return _number(stats['lastPrice'] ?? stats['last'] ?? row['lastPrice']);
  }

  Future<List<OhlcCandle>> _wallexCandles() async {
    try {
      final now = DateTime.now().millisecondsSinceEpoch ~/ 1000;
      final uri = Uri.https('api.wallex.ir', '/v1/udf/history', {'symbol': 'BTCUSDT', 'resolution': '60', 'from': '${now - 60 * 60 * 80}', 'to': '$now'});
      final json = await _getJson(uri);
      final t = _list(json['t']); final o = _list(json['o']); final h = _list(json['h']);
      final l = _list(json['l']); final c = _list(json['c']); final v = _list(json['v']);
      final out = <OhlcCandle>[];
      for (var i = 0; i < t.length && i < o.length && i < h.length && i < l.length && i < c.length; i++) {
        out.add(OhlcCandle(time: DateTime.fromMillisecondsSinceEpoch(_number(t[i]).toInt() * 1000), open: _number(o[i]), high: _number(h[i]), low: _number(l[i]), close: _number(c[i]), volume: i < v.length ? _number(v[i]) : 0));
      }
      return out;
    } catch (_) { return const []; }
  }

  Future<_AdapterResult> _loadBitpin() async {
    try {
      final json = await _getJson(Uri.https('api.bitpin.org', '/api/v1/mkt/tickers/'));
      final rows = _extractRows(json);
      final indexed = <String, Map<String, dynamic>>{};
      for (final row in rows) {
        final pair = (row['symbol'] ?? row['market'] ?? row['code'] ?? '').toString().toUpperCase().replaceAll('/', '_').replaceAll('-', '_');
        if (pair.isNotEmpty) indexed[pair] = row;
      }
      final markets = <String, LiveMarket>{};
      final usdtIrt = _bitpinLast(indexed, 'USDT_IRT');
      for (final symbol in _assets.keys.where((s) => s != 'USDT')) {
        final toman = _bitpinLast(indexed, '${symbol}_IRT');
        final usdt = _bitpinLast(indexed, '${symbol}_USDT');
        final row = indexed['${symbol}_IRT'] ?? indexed['${symbol}_USDT'] ?? {};
        final change = _number(row['change'] ?? row['change_percent'] ?? row['percentage'] ?? row['dayChange']);
        if (toman > 0 || usdt > 0) {
          markets[symbol] = LiveMarket(symbol: symbol, name: _assets[symbol]!, toman: toman > 0 ? toman : usdt * usdtIrt, usdt: usdt > 0 ? usdt : (usdtIrt > 0 ? toman / usdtIrt : 0), changePercent: change, source: 'بیت‌پین');
        }
      }
      if (usdtIrt > 0) markets['USDT'] = LiveMarket(symbol: 'USDT', name: _assets['USDT']!, toman: usdtIrt, usdt: 1, changePercent: 0, source: 'بیت‌پین');
      final candles = await _bitpinCandles();
      return _AdapterResult(ExchangeConnection(name: 'بیت‌پین', connected: markets.isNotEmpty), markets, candles);
    } catch (e) {
      return _AdapterResult(ExchangeConnection(name: 'بیت‌پین', connected: false, message: _shortError(e)), {}, const []);
    }
  }

  double _bitpinLast(Map<String, Map<String, dynamic>> indexed, String pair) {
    final row = indexed[pair] ?? {};
    return _number(row['last'] ?? row['last_price'] ?? row['price'] ?? row['close'] ?? row['lastPrice']);
  }

  Future<List<OhlcCandle>> _bitpinCandles() async {
    try {
      final now = DateTime.now().millisecondsSinceEpoch ~/ 1000;
      final uri = Uri.https('api.bitpin.org', '/api/v1/mkt/candles/', {'symbol': 'BTC_USDT', 'res': '1h', 'from': '${now - 60 * 60 * 80}', 'to': '$now'});
      final json = await _getJson(uri);
      final rawRows = json is List ? json : (_map(json)['results'] is List ? _map(json)['results'] as List : (_map(json)['data'] is List ? _map(json)['data'] as List : const []));
      final rows = rawRows.map((entry) {
        if (entry is List && entry.length >= 6) {
          return <String, dynamic>{'t': entry[0], 'o': entry[1], 'h': entry[2], 'l': entry[3], 'c': entry[4], 'v': entry[5]};
        }
        return _map(entry);
      }).toList();
      final out = <OhlcCandle>[];
      for (final row in rows) {
        final time = _number(row['timestamp'] ?? row['time'] ?? row['t']).toInt();
        if (time <= 0) continue;
        out.add(OhlcCandle(time: DateTime.fromMillisecondsSinceEpoch(time < 1000000000000 ? time * 1000 : time), open: _number(row['open'] ?? row['o']), high: _number(row['high'] ?? row['h']), low: _number(row['low'] ?? row['l']), close: _number(row['close'] ?? row['c']), volume: _number(row['volume'] ?? row['v'])));
      }
      return out;
    } catch (_) { return const []; }
  }

  Future<dynamic> _getJson(Uri uri) async {
    final response = await _client.get(uri, headers: const {'Accept': 'application/json'}).timeout(_timeout);
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('HTTP ${response.statusCode}');
    }
    return jsonDecode(utf8.decode(response.bodyBytes));
  }

  List<Map<String, dynamic>> _extractRows(dynamic json) {
    if (json is List) return json.map(_map).toList();
    final map = _map(json);
    for (final key in ['results', 'data', 'tickers', 'candles']) {
      final value = map[key];
      if (value is List) return value.map(_map).toList();
      if (value is Map) {
        return value.entries.map((entry) {
          final row = _map(entry.value);
          row.putIfAbsent('symbol', () => entry.key.toString());
          return row;
        }).toList();
      }
    }
    if (map.values.isNotEmpty && map.values.every((v) => v is Map)) {
      return map.entries.map((entry) {
        final row = _map(entry.value);
        row.putIfAbsent('symbol', () => entry.key.toString());
        return row;
      }).toList();
    }
    return const [];
  }

  Map<String, dynamic> _map(dynamic value) => value is Map ? value.map((k, v) => MapEntry(k.toString(), v)) : <String, dynamic>{};
  List<dynamic> _list(dynamic value) => value is List ? value : const [];
  double _number(dynamic value) => double.tryParse(value?.toString() ?? '') ?? 0;
  String _shortError(Object e) => e.toString().replaceFirst('Exception: ', '').split('\n').first;

  void dispose() => _client.close();
}

class _AdapterResult {
  const _AdapterResult(this.connection, this.markets, this.candles);
  final ExchangeConnection connection;
  final Map<String, LiveMarket> markets;
  final List<OhlcCandle> candles;
}
