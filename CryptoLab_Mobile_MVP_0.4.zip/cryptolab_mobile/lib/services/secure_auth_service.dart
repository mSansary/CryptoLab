import 'dart:convert';
import 'dart:math';

import 'package:cryptography/cryptography.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:local_auth/local_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SecureAuthService {
  SecureAuthService({FlutterSecureStorage? storage, LocalAuthentication? biometric})
      : _storage = storage ?? const FlutterSecureStorage(),
        _biometric = biometric ?? LocalAuthentication();

  final FlutterSecureStorage _storage;
  final LocalAuthentication _biometric;
  static const _saltKey = 'cryptolab_password_salt_v1';
  static const _hashKey = 'cryptolab_password_hash_v1';
  static const _biometricKey = 'biometric_login_enabled';
  final _kdf = Pbkdf2(macAlgorithm: Hmac.sha256(), iterations: 120000, bits: 256);

  Future<bool> hasPassword() async => (await _storage.read(key: _hashKey)) != null;

  Future<void> setPassword(String password, SharedPreferences prefs) async {
    if (password.length < 6) throw ArgumentError('رمز باید حداقل ۶ نویسه باشد.');
    final salt = List<int>.generate(16, (_) => Random.secure().nextInt(256));
    final key = await _kdf.deriveKey(secretKey: SecretKey(utf8.encode(password)), nonce: salt);
    await _storage.write(key: _saltKey, value: base64Encode(salt));
    await _storage.write(key: _hashKey, value: base64Encode(await key.extractBytes()));
    await prefs.setBool(_biometricKey, false);
  }

  Future<bool> verifyPassword(String password) async {
    final saltText = await _storage.read(key: _saltKey);
    final hashText = await _storage.read(key: _hashKey);
    if (saltText == null || hashText == null) return false;
    final key = await _kdf.deriveKey(secretKey: SecretKey(utf8.encode(password)), nonce: base64Decode(saltText));
    final actual = await key.extractBytes();
    final expected = base64Decode(hashText);
    if (actual.length != expected.length) return false;
    var diff = 0;
    for (var i = 0; i < actual.length; i++) { diff |= actual[i] ^ expected[i]; }
    return diff == 0;
  }

  Future<bool> canUseBiometrics() async {
    try { return await _biometric.isDeviceSupported() && await _biometric.canCheckBiometrics; }
    catch (_) { return false; }
  }

  Future<bool> authenticateBiometric() async {
    try {
      return await _biometric.authenticate(
        localizedReason: 'برای ورود امن به CryptoLab هویت خود را تأیید کنید',
        options: const AuthenticationOptions(biometricOnly: true, stickyAuth: true),
      );
    } catch (_) { return false; }
  }

  Future<bool> biometricEnabled(SharedPreferences prefs) async => prefs.getBool(_biometricKey) ?? false;
  Future<void> setBiometricEnabled(SharedPreferences prefs, bool value) async {
    await prefs.setBool(_biometricKey, value);
  }
}
