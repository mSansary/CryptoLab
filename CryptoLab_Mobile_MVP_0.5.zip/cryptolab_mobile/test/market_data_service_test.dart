import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:cryptolab_mobile/services/market_data_service.dart';

http.Response _json(Object body) => http.Response(
      jsonEncode(body),
      200,
      headers: const {'content-type': 'application/json'},
    );

void main() {
  group('MarketDataService public exchange adapters', () {
    test('parses market prices and Toman candles from all three exchanges', () async {
      final client = MockClient((request) async {
        if (request.host == 'apiv2.nobitex.ir' && request.path == '/market/stats') {
          return _json({
            'status': 'ok',
            'stats': {
              'btc-rls': {'latest': '1000000000', 'dayChange': '1.5'},
              'usdt-rls': {'latest': '600000', 'dayChange': '0.2'},
            },
          });
        }
        if (request.host == 'apiv2.nobitex.ir' && request.path == '/market/udf/history') {
          return _json({
            's': 'ok',
            't': [1761552000],
            'o': [1000000000],
            'h': [1010000000],
            'l': [990000000],
            'c': [1005000000],
            'v': [2],
          });
        }
        if (request.host == 'api.wallex.ir' && request.path == '/v1/markets') {
          return _json({
            'success': true,
            'result': {
              'symbols': {
                'USDTTMN': {'stats': {'lastPrice': '61000', '24h_ch': 0.1}},
                'BTCTMN': {'stats': {'lastPrice': '6100000000', '24h_ch': 1.2}},
              },
            },
          });
        }
        if (request.host == 'api.wallex.ir' && request.path == '/v1/udf/history') {
          return _json({
            's': 'ok',
            't': [1761552000],
            'o': ['6100000000'],
            'h': ['6200000000'],
            'l': ['6000000000'],
            'c': ['6150000000'],
            'v': ['1.2'],
          });
        }
        if (request.host == 'api.bitpin.org' && request.path == '/api/v1/mkt/tickers/') {
          return _json({
            'status': 200,
            'body': [
              {'symbol': 'BTC_IRT', 'price': '6200000000', 'daily_change_price': 0.01},
              {'symbol': 'USDT_IRT', 'price': '62000', 'daily_change_price': 0.002},
            ],
          });
        }
        if (request.host == 'api.bitpin.org' && request.path == '/api/v1/mkt/candles/') {
          return _json({
            'status': 200,
            'body': [
              {
                'open': 6200000000,
                'close': 6210000000,
                'low': 6190000000,
                'high': 6220000000,
                'volume': '0.8',
                'time': 1761552000000,
                'resolution': '1h',
              },
            ],
          });
        }
        return http.Response('not found', 404);
      });

      final service = MarketDataService(client: client);
      final result = await service.load();

      expect(result.connections, hasLength(3));
      expect(result.connections.every((item) => item.connected), isTrue);
      expect(result.markets['BTC']!.source, 'نوبیتکس');
      expect(result.markets['BTC']!.toman, 100000000);
      expect(result.markets['USDT']!.toman, 60000);
      expect(result.candles, hasLength(1));
      expect(result.candleSource, 'نوبیتکس');
      expect(result.candles.single.close, 100500000);
      service.dispose();
    });

    test('keeps Bitpin data available when the other exchanges fail', () async {
      final client = MockClient((request) async {
        if (request.host == 'api.bitpin.org' && request.path == '/api/v1/mkt/tickers/') {
          return _json({
            'status': 200,
            'body': [
              {'symbol': 'BTC_IRT', 'price': '7000000000', 'daily_change_price': -0.02},
              {'symbol': 'USDT_IRT', 'price': '70000', 'daily_change_price': 0},
            ],
          });
        }
        if (request.host == 'api.bitpin.org' && request.path == '/api/v1/mkt/candles/') {
          return _json({
            'status': 200,
            'body': [
              {
                'open': 6900000000,
                'close': 7000000000,
                'low': 6800000000,
                'high': 7100000000,
                'volume': '1',
                'time': 1761552000000,
              },
            ],
          });
        }
        return http.Response('service unavailable', 503);
      });

      final service = MarketDataService(client: client);
      final result = await service.load();

      expect(result.connections.where((item) => item.connected).map((e) => e.name), ['بیت‌پین']);
      expect(result.markets['BTC']!.source, 'بیت‌پین');
      expect(result.markets['BTC']!.toman, 7000000000);
      expect(result.markets['BTC']!.usdt, 100000);
      expect(result.markets['BTC']!.changePercent, -2);
      expect(result.candles.single.close, 7000000000);
      expect(result.candleSource, 'بیت‌پین');
      service.dispose();
    });
  });
}
