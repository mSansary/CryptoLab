import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:cryptolab_mobile/main.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('renders CryptoLab mobile dashboard and navigation', (tester) async {
    SharedPreferences.setMockInitialValues({});
    final prefs = await SharedPreferences.getInstance();
    await tester.pumpWidget(CryptoLabApp(prefs: prefs));
    expect(find.text('Crypto'), findsOneWidget);
    expect(find.text('داشبورد معاملاتی'), findsOneWidget);
    expect(find.text('نمودار کندلی · داده نمایشی'), findsOneWidget);
    expect(find.text('45,506.81 USDT'), findsOneWidget);
    expect(find.text('بازار'), findsOneWidget);
    expect(find.text('استراتژی'), findsOneWidget);
    expect(find.text('دارایی'), findsOneWidget);
  });
}
