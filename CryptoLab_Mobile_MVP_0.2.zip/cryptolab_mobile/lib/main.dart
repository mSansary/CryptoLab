import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  runApp(CryptoLabApp(prefs: prefs));
}

class CryptoLabApp extends StatefulWidget {
  const CryptoLabApp({super.key, required this.prefs});
  final SharedPreferences prefs;

  @override
  State<CryptoLabApp> createState() => _CryptoLabAppState();
}

class _CryptoLabAppState extends State<CryptoLabApp> {
  late ThemeMode _themeMode;

  @override
  void initState() {
    super.initState();
    _themeMode = widget.prefs.getBool('dark_mode') == true
        ? ThemeMode.dark
        : ThemeMode.light;
  }

  Future<void> _toggleTheme() async {
    setState(() {
      _themeMode =
          _themeMode == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark;
    });
    await widget.prefs.setBool('dark_mode', _themeMode == ThemeMode.dark);
  }

  @override
  Widget build(BuildContext context) {
    const blue = Color(0xFF2878D2);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'CryptoLab',
      themeMode: _themeMode,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.light,
        scaffoldBackgroundColor: const Color(0xFFF1F6FF),
        colorScheme: ColorScheme.fromSeed(
          seedColor: blue,
          brightness: Brightness.light,
          surface: Colors.white,
        ),
        cardTheme: CardTheme(
          color: Colors.white,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
            side: const BorderSide(color: Color(0xFFE2EAF5)),
          ),
        ),
        fontFamily: 'Roboto',
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF07152A),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF65AFFF),
          brightness: Brightness.dark,
          surface: const Color(0xFF10233D),
        ),
        cardTheme: CardTheme(
          color: const Color(0xFF10233D),
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
            side: const BorderSide(color: Color(0xFF29425E)),
          ),
        ),
      ),
      builder: (context, child) => Directionality(
        textDirection: TextDirection.rtl,
        child: child!,
      ),
      home: HomeShell(
        prefs: widget.prefs,
        isDark: _themeMode == ThemeMode.dark,
        onToggleTheme: _toggleTheme,
      ),
    );
  }
}

class Coin {
  const Coin({
    required this.symbol,
    required this.name,
    required this.price,
    required this.priceUsdt,
    required this.change,
    required this.up,
    required this.icon,
  });
  final String symbol;
  final String name;
  final String price;
  final String priceUsdt;
  final String change;
  final bool up;
  final String icon;
}

const demoCoins = <Coin>[
  Coin(symbol: 'BTC', name: 'بیت‌کوین', price: '3,842,750,000', priceUsdt: '45,506.81', change: '+2.37%', up: true, icon: '₿'),
  Coin(symbol: 'ETH', name: 'اتریوم', price: '172,320,000', priceUsdt: '2,041.09', change: '+1.85%', up: true, icon: '◆'),
  Coin(symbol: 'USDT', name: 'تتر', price: '84,450', priceUsdt: '1.00', change: '+0.12%', up: true, icon: '₮'),
  Coin(symbol: 'SOL', name: 'سولانا', price: '9,850,000', priceUsdt: '116.64', change: '−0.72%', up: false, icon: '◎'),
  Coin(symbol: 'BNB', name: 'بایننس کوین', price: '62,800,000', priceUsdt: '743.63', change: '+0.93%', up: true, icon: '◆'),
];

class HomeShell extends StatefulWidget {
  const HomeShell({
    super.key,
    required this.prefs,
    required this.isDark,
    required this.onToggleTheme,
  });

  final SharedPreferences prefs;
  final bool isDark;
  final VoidCallback onToggleTheme;

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;
  String _tradeSide = 'خرید';
  String _amount = '1000000';
  late final TextEditingController _amountController;
  bool _botRunning = false;
  late Set<String> _favorites;

  @override
  void initState() {
    super.initState();
    _favorites = (widget.prefs.getStringList('favorites') ?? ['BTC', 'ETH', 'USDT']).toSet();
    _amountController = TextEditingController(text: _formatGrouped(_amount));
  }

  @override
  void dispose() {
    _amountController.dispose();
    super.dispose();
  }

  Color get _muted => Theme.of(context).brightness == Brightness.dark
      ? const Color(0xFFA6B8D0)
      : const Color(0xFF697D99);
  Color get _blue => Theme.of(context).colorScheme.primary;
  Color get _green => Theme.of(context).brightness == Brightness.dark
      ? const Color(0xFF21D59A)
      : const Color(0xFF159C6B);
  Color get _gold => Theme.of(context).brightness == Brightness.dark
      ? const Color(0xFFFFC94D)
      : const Color(0xFFE6AB28);

  String _formatGrouped(String input) {
    final digits = input.replaceAll(RegExp(r'[^0-9]'), '');
    if (digits.isEmpty) return '';
    final out = StringBuffer();
    for (var i = 0; i < digits.length; i++) {
      if (i > 0 && (digits.length - i) % 3 == 0) out.write(',');
      out.write(digits[i]);
    }
    return out.toString();
  }

  Future<void> _toggleFavorite(String symbol) async {
    setState(() {
      if (!_favorites.add(symbol)) _favorites.remove(symbol);
    });
    await widget.prefs.setStringList('favorites', _favorites.toList());
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), behavior: SnackBarBehavior.floating),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _dashboard(),
      _market(),
      _strategies(),
      _assets(),
    ];
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 18,
        title: Row(
          children: [
            Icon(Icons.auto_graph_rounded, color: _gold, size: 29),
            const SizedBox(width: 7),
            const Text.rich(TextSpan(children: [
              TextSpan(text: 'Crypto', style: TextStyle(fontWeight: FontWeight.w900)),
              TextSpan(text: 'Lab', style: TextStyle(color: Color(0xFFE6AB28), fontWeight: FontWeight.w900)),
            ])),
          ],
        ),
        actions: [
          IconButton(
            tooltip: widget.isDark ? 'تم روشن' : 'تم تیره',
            onPressed: widget.onToggleTheme,
            icon: Icon(widget.isDark ? Icons.light_mode_rounded : Icons.dark_mode_rounded),
          ),
          IconButton(
            tooltip: 'اعلان‌ها',
            onPressed: () => _showMessage('اعلان‌های نمایشی CryptoLab'),
            icon: const Icon(Icons.notifications_none_rounded),
          ),
          const SizedBox(width: 4),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(14, 4, 14, 18),
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(_pageTitle, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
                const _DemoBadge(),
              ],
            ),
            const SizedBox(height: 12),
            pages[_index],
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (value) => setState(() => _index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: 'خانه'),
          NavigationDestination(icon: Icon(Icons.candlestick_chart_outlined), selectedIcon: Icon(Icons.candlestick_chart_rounded), label: 'بازار'),
          NavigationDestination(icon: Icon(Icons.smart_toy_outlined), selectedIcon: Icon(Icons.smart_toy_rounded), label: 'استراتژی'),
          NavigationDestination(icon: Icon(Icons.account_balance_wallet_outlined), selectedIcon: Icon(Icons.account_balance_wallet_rounded), label: 'دارایی'),
        ],
      ),
    );
  }

  String get _pageTitle => const ['داشبورد معاملاتی', 'بازار رمزارزها', 'استراتژی و ربات‌ها', 'دارایی‌های من'][_index];

  Widget _dashboard() {
    return Column(
      children: [
        Row(children: [
          Expanded(child: _summaryCard('ارزش کل دارایی', '152,430,000', 'تومان', Icons.account_balance_wallet_rounded, _blue)),
        ]),
        const SizedBox(height: 9),
        Row(children: [
          Expanded(child: _summaryCard('موجودی تتر', '1,250.75', 'USDT', Icons.toll_rounded, _green)),
          const SizedBox(width: 9),
          Expanded(child: _summaryCard('موجودی ریالی', '78,350,000', 'تومان', Icons.account_balance_rounded, _gold)),
        ]),
        const SizedBox(height: 9),
        Card(
          color: Theme.of(context).brightness == Brightness.dark
              ? const Color(0xFF103B39)
              : const Color(0xFFDDF7EF),
          child: Padding(
            padding: const EdgeInsets.all(15),
            child: Row(children: [
              Icon(Icons.trending_up_rounded, color: _green, size: 34),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('سود و زیان امروز', style: TextStyle(color: _muted)),
                Text('+3.24% ▲', style: TextStyle(color: _green, fontSize: 23, fontWeight: FontWeight.w900)),
                Text('+4,780,000 تومان', style: TextStyle(color: _green, fontWeight: FontWeight.w700)),
              ])),
            ]),
          ),
        ),
        const SizedBox(height: 9),
        _chartCard(),
        const SizedBox(height: 9),
        _favoritesCard(),
        const SizedBox(height: 9),
        _exchangesCard(),
        const SizedBox(height: 9),
        _botCard(),
        const SizedBox(height: 9),
        _eventsCard(),
      ],
    );
  }

  Widget _summaryCard(String title, String value, String unit, IconData icon, Color color) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(13),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Icon(icon, color: color, size: 22),
            const SizedBox(width: 7),
            Expanded(child: Text(title, style: TextStyle(color: _muted, fontSize: 12))),
          ]),
          const SizedBox(height: 8),
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerRight,
            child: Text(value, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
          ),
          Text(unit, style: TextStyle(color: _muted, fontSize: 11)),
        ]),
      ),
    );
  }

  Widget _chartCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            CircleAvatar(backgroundColor: const Color(0xFFF7931A), radius: 17, child: const Text('₿', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 20))),
            const SizedBox(width: 9),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('بیت‌کوین (BTC)', style: TextStyle(fontWeight: FontWeight.w800)),
              Wrap(spacing: 8, runSpacing: 2, crossAxisAlignment: WrapCrossAlignment.center, children: [
                const Text('3,842,750,000 تومان', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900)),
                const Text('45,506.81 USDT', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: Color(0xFF8092A8))),
                Text('+2.37% ▲', style: TextStyle(color: _green, fontWeight: FontWeight.w800, fontSize: 12)),
              ]),
            ])),
          ]),
          const SizedBox(height: 12),
          SizedBox(height: 142, child: CustomPaint(painter: PriceChartPainter(
            gridColor: Theme.of(context).dividerColor.withOpacity(.55),
            green: _green,
            red: const Color(0xFFDA5265),
          ), child: const SizedBox.expand())),
          const SizedBox(height: 4),
          Text('نمودار کندلی · داده نمایشی', style: TextStyle(color: _muted, fontSize: 10)),
        ]),
      ),
    );
  }

  Widget _favoritesCard() {
    final selected = demoCoins.where((c) => _favorites.contains(c.symbol)).toList();
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            const Text('بازارهای منتخب ⭐', style: TextStyle(fontWeight: FontWeight.w900)),
            TextButton(onPressed: () => setState(() => _index = 1), child: const Text('مدیریت')),
          ]),
          if (selected.isEmpty)
            Text('هنوز ارزی انتخاب نشده است.', style: TextStyle(color: _muted))
          else
            ...selected.map(_coinRow),
        ]),
      ),
    );
  }

  Widget _coinRow(Coin coin) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 8),
    child: Row(children: [
      CircleAvatar(radius: 16, backgroundColor: Theme.of(context).colorScheme.surfaceContainerHighest, child: Text(coin.icon, style: TextStyle(color: _blue, fontWeight: FontWeight.w900))),
      const SizedBox(width: 9),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(coin.name, style: const TextStyle(fontWeight: FontWeight.w700)),
        Text(coin.symbol, style: TextStyle(color: _muted, fontSize: 11)),
      ])),
      Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
        Text('${coin.price} تومان', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 11)),
        Text('${coin.priceUsdt} USDT', style: TextStyle(color: _muted, fontSize: 10)),
        Text(coin.change, style: TextStyle(color: coin.up ? _green : const Color(0xFFDA5265), fontSize: 11, fontWeight: FontWeight.w800)),
      ]),
      IconButton(
        visualDensity: VisualDensity.compact,
        onPressed: () => _toggleFavorite(coin.symbol),
        icon: Icon(Icons.star_rounded, color: _favorites.contains(coin.symbol) ? _gold : _muted),
      ),
    ]),
  );

  Widget _exchangesCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('مدیریت حساب‌های صرافی', style: TextStyle(fontWeight: FontWeight.w900)),
          const SizedBox(height: 10),
          Row(children: [
            _exchangeTile('نوبیتکس', Icons.currency_exchange, const Color(0xFF8C52E8)),
            const SizedBox(width: 7),
            _exchangeTile('والکس', Icons.swap_horiz_rounded, _blue),
            const SizedBox(width: 7),
            _exchangeTile('بیت‌پین', Icons.account_balance_rounded, _green),
          ]),
        ]),
      ),
    );
  }

  Widget _exchangeTile(String name, IconData icon, Color color) => Expanded(
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 4),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceContainerHighest.withOpacity(.65),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(children: [
        Icon(icon, color: color, size: 28),
        const SizedBox(height: 5),
        Text(name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 11)),
        Text('اتصال بعداً', style: TextStyle(color: _muted, fontSize: 9)),
      ]),
    ),
  );

  Widget _botCard() => Card(
    child: Padding(
      padding: const EdgeInsets.all(14),
      child: Row(children: [
        Icon(Icons.smart_toy_rounded, color: _blue, size: 30),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('وضعیت ربات', style: TextStyle(fontWeight: FontWeight.w900)),
          Text(_botRunning ? 'ربات نمایشی فعال' : 'ربات متوقف است', style: TextStyle(color: _botRunning ? _green : _muted)),
          Text('استراتژی: دنبال‌کننده روند', style: TextStyle(color: _muted, fontSize: 11)),
        ])),
        FilledButton.tonal(
          onPressed: () => setState(() => _botRunning = !_botRunning),
          child: Text(_botRunning ? 'توقف' : 'شروع'),
        ),
      ]),
    ),
  );

  Widget _eventsCard() => Card(
    child: Padding(
      padding: const EdgeInsets.all(14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('آخرین رویدادها', style: TextStyle(fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        _event('12:32', 'سفارش آزمایشی خرید BTC ثبت شد'),
        _event('11:45', 'سیگنال نمایشی برای ETH صادر شد'),
      ]),
    ),
  );

  Widget _event(String time, String text) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 5),
    child: Row(children: [
      Icon(Icons.circle, size: 8, color: _green),
      const SizedBox(width: 7),
      Expanded(child: Text(text, style: const TextStyle(fontSize: 12))),
      Text(time, style: TextStyle(color: _muted, fontSize: 10)),
    ]),
  );

  Widget _market() => Column(children: [
    Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(children: [
          const Text('فهرست بازار', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
          const SizedBox(height: 8),
          ...demoCoins.map((coin) => _coinRow(coin)),
        ]),
      ),
    ),
    const SizedBox(height: 10),
    Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('معامله سریع · پیش‌نمایش سفارش', style: TextStyle(fontWeight: FontWeight.w900)),
          const SizedBox(height: 10),
          SegmentedButton<String>(
            showSelectedIcon: false,
            segments: const [
              ButtonSegment(value: 'خرید', label: Text('خرید')),
              ButtonSegment(value: 'فروش', label: Text('فروش')),
            ],
            selected: {_tradeSide},
            onSelectionChanged: (s) => setState(() => _tradeSide = s.first),
          ),
          const SizedBox(height: 10),
          TextField(
            keyboardType: TextInputType.number,
            controller: _amountController,
            inputFormatters: [ThousandsSeparatorInputFormatter()],
            onChanged: (v) => _amount = v.replaceAll(',', ''),
            decoration: const InputDecoration(labelText: 'مبلغ به تومان', border: OutlineInputBorder()),
          ),
          const SizedBox(height: 10),
          SizedBox(width: double.infinity, child: FilledButton(
            style: FilledButton.styleFrom(backgroundColor: _tradeSide == 'خرید' ? _green : const Color(0xFFDA5265)),
            onPressed: () => _showMessage('پیش‌نمایش $_tradeSide به مبلغ ${_formatGrouped(_amount)} تومان؛ هیچ سفارش واقعی ارسال نشد.'),
            child: Text('ثبت پیش‌نمایش $_tradeSide'),
          )),
        ]),
      ),
    ),
  ]);

  Widget _strategies() => Column(children: [
    ...[
      ('Trend Following', 'دنبال‌کردن روند با EMA و MACD'),
      ('Breakout', 'شناسایی شکست حمایت و مقاومت'),
      ('Mean Reversion', 'بازگشت قیمت به میانگین'),
      ('Grid Trading', 'معاملات شبکه‌ای در محدوده قیمت'),
      ('Momentum', 'تحلیل شتاب حرکت بازار'),
    ].map((item) => Card(
      child: ListTile(
        leading: Icon(Icons.auto_graph_rounded, color: _blue),
        title: Text(item.$1, style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text(item.$2),
        trailing: IconButton(
          icon: const Icon(Icons.chevron_left),
          onPressed: () => _showMessage('جزئیات ${item.$1} در مرحله بعد تکمیل می‌شود.'),
        ),
      ),
    )),
    Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(children: [
          const Text('کنترل اجرای ربات', style: TextStyle(fontWeight: FontWeight.w900)),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('ربات نمایشی'),
            subtitle: const Text('این کلید هنوز به معامله واقعی متصل نیست.'),
            value: _botRunning,
            onChanged: (v) => setState(() => _botRunning = v),
          ),
        ]),
      ),
    ),
  ]);

  Widget _assets() => Column(children: [
    Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('ارزش کل دارایی', style: TextStyle(color: _muted)),
          const SizedBox(height: 5),
          const Text('152,430,000 تومان', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 25)),
          Text('مقادیر نمونه و غیرزنده', style: TextStyle(color: _muted, fontSize: 11)),
        ]),
      ),
    ),
    ...[
      ('Bitcoin', '0.04 BTC', '154,000,000 تومان'),
      ('Ethereum', '0.5 ETH', '64,250,000 تومان'),
      ('Tether', '270 USDT', '30,240,000 تومان'),
    ].map((a) => Card(
      child: ListTile(
        leading: CircleAvatar(backgroundColor: Theme.of(context).colorScheme.surfaceContainerHighest, child: Icon(Icons.currency_bitcoin, color: _blue)),
        title: Text(a.$1, style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text(a.$2),
        trailing: Text(a.$3, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 11)),
      ),
    )),
    Card(
      child: Column(children: [
        ListTile(
          leading: const Icon(Icons.lock_outline),
          title: const Text('امنیت و قفل برنامه'),
          trailing: const Icon(Icons.chevron_left),
          onTap: () => _showMessage('قفل بیومتریک و مدیریت کلیدها در مرحله امنیت پیاده‌سازی می‌شود.'),
        ),
        const Divider(height: 1),
        ListTile(
          leading: const Icon(Icons.backup_outlined),
          title: const Text('پشتیبان‌گیری محلی'),
          trailing: const Icon(Icons.chevron_left),
          onTap: () => _showMessage('بکاپ رمزنگاری‌شده در مرحله ذخیره‌سازی اضافه می‌شود.'),
        ),
      ]),
    ),
  ]);
}

class ThousandsSeparatorInputFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    final digits = newValue.text.replaceAll(RegExp(r'[^0-9]'), '');
    final formatted = _groupDigits(digits);
    return TextEditingValue(
      text: formatted,
      selection: TextSelection.collapsed(offset: formatted.length),
    );
  }

  String _groupDigits(String digits) {
    if (digits.isEmpty) return '';
    final result = StringBuffer();
    for (var i = 0; i < digits.length; i++) {
      if (i > 0 && (digits.length - i) % 3 == 0) result.write(',');
      result.write(digits[i]);
    }
    return result.toString();
  }
}

class _DemoBadge extends StatelessWidget {
  const _DemoBadge();
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
    decoration: BoxDecoration(
      color: const Color(0xFFFFF0C7),
      borderRadius: BorderRadius.circular(20),
    ),
    child: const Text('DEMO', style: TextStyle(color: Color(0xFF956A08), fontWeight: FontWeight.w900, fontSize: 10)),
  );
}

class PriceChartPainter extends CustomPainter {
  PriceChartPainter({
    required this.gridColor,
    required this.green,
    required this.red,
  });
  final Color gridColor;
  final Color green;
  final Color red;

  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()..color = gridColor..strokeWidth = 1;
    for (var i = 1; i <= 4; i++) {
      final y = size.height * i / 5;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }

    // Deterministic illustrative OHLC candles; live exchange candles will replace these.
    const closes = <double>[.72,.68,.70,.61,.64,.56,.59,.48,.52,.45,.49,.39,.43,.34,.38,.42,.35,.29,.33,.24,.28,.32,.25,.30,.22,.26,.18,.23,.16,.20];
    const deltas = <double>[.035,-.025,.018,-.04,.022,-.03,.026,-.045,.025,-.02,.03,-.04,.025,-.03,.02,.035,-.03,-.025,.03,-.04,.025,.02,-.035,.04,-.03,.025,-.04,.035,-.025,.03];
    final candleWidth = size.width / (closes.length * 1.65);
    for (var i = 0; i < closes.length; i++) {
      final x = size.width * (i + .5) / closes.length;
      final close = closes[i];
      final open = close - deltas[i];
      final high = (open > close ? open : close) + .035 + (i % 3) * .006;
      final low = (open < close ? open : close) - .03 - (i % 4) * .005;
      final rising = close < open;
      final color = rising ? green : red;
      final paint = Paint()..color = color..strokeWidth = 1.2;
      canvas.drawLine(Offset(x, size.height * high), Offset(x, size.height * low), paint);
      final top = size.height * (open < close ? open : close);
      final bottom = size.height * (open > close ? open : close);
      final bodyHeight = (bottom - top).abs().clamp(3.0, size.height).toDouble();
      canvas.drawRect(
        Rect.fromCenter(center: Offset(x, (top + bottom) / 2), width: candleWidth, height: bodyHeight),
        Paint()..color = color,
      );
    }

    final volumeBase = size.height - 2;
    for (var i = 0; i < closes.length; i++) {
      final x = size.width * (i + .5) / closes.length;
      final h = 4.0 + (i % 6) * 1.6;
      canvas.drawRect(
        Rect.fromLTWH(x - candleWidth / 2, volumeBase - h, candleWidth, h),
        Paint()..color = (i % 3 == 0 ? red : green).withOpacity(.45),
      );
    }
  }

  @override
  bool shouldRepaint(covariant PriceChartPainter oldDelegate) =>
      oldDelegate.gridColor != gridColor ||
      oldDelegate.green != green ||
      oldDelegate.red != red;
}
